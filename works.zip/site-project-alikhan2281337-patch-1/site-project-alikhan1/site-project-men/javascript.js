var video = document.getElementById("myVideo");

function playVideo() {
    video.style.display = "block"; 
    video.play(); 
}

function pauseVideo() {
    video.pause(); 
}
