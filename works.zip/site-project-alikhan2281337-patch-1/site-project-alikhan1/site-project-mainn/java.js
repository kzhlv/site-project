// let isAuth = false

// let urlSites = document.querySelectorAll('.url')
// console.log(urlSites)

// urlSites.forEach(element => {
//     element.addEventListener('click', (event) => {
//         if (!isAuth) {
//             event.preventDefault();
//             window.location.href = '/site-project-main2/registration2.html';
//         }  
            
//     })
// });
